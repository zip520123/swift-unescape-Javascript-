import Foundation
import UIKit

let quickFox = "The quick brown fox jumps over the lazy dog."
public extension String {
	
	public func rangeFromNSRange(aRange: NSRange) -> Range<String.Index> {
		let s = self.startIndex.advancedBy(aRange.location)
		let e = self.startIndex.advancedBy(aRange.location + aRange.length)
		return s..<e
	}
	public var ns : NSString {return self as NSString}
	public subscript (aRange: NSRange) -> String? {
		get {return self.substringWithRange(self.rangeFromNSRange(aRange))}
	}
	
	public var cdr: String {return isEmpty ? "" : String(characters.dropFirst())}
	
	public func toCamel() throws -> String {
		var s = self
		let regex = try NSRegularExpression(pattern: "_+(.)", options: [])
		let matches = regex.matchesInString(s, options:[], range:NSMakeRange(0, s.ns.length)).reverse()
		for match in matches {
			print("match = \(s[match.range]!)")
			let matchRange = s.rangeFromNSRange(match.range) // the whole match range
			let replaceRange = match.rangeAtIndex(1)         // range of the capture group
			let uc = s[replaceRange]!.uppercaseString
			s.replaceRange(matchRange, with: uc)
		}
		if s.hasPrefix("_") {s = s.cdr}
		return s
	}
}


func findNumber(inputS:String , patte:String) throws -> CGFloat{
	let regex = try NSRegularExpression(pattern: patte + ": \\d+", options: [])
	let ns1 = inputS as NSString
	let int2 = regex.matchesInString(inputS, options: [], range: NSMakeRange(0, ns1.length))
	for item in int2 {
		let r1 = item.rangeAtIndex(0)
		let regex2 = try NSRegularExpression(pattern: "\\d+", options: [])
		let int3 = regex2.firstMatchInString(inputS[r1]!, options: [], range: NSMakeRange(0, inputS[r1]!.ns.length))
		let r2 = int3?.rangeAtIndex(0)
		let input2 = inputS[r1]
		let fInt = CGFloat(Int(input2![r2!]!)!)
		return fInt
	}
	return 0
}
func findMp4FileString(inputS:String) throws -> [String]{

	let regex = try NSRegularExpression(pattern: "\\d+", options: [])
	

	let int2 = regex.matchesInString(inputS, options: [], range: NSMakeRange(0, inputS.ns.length))
	return []
}
let a01 = "position: absolute; z-index: 5; left: 660px; top: 259px; width: 366px; height: 268px; font-size: 15pt; font-family: Arial, 'Arial Unicode MS';"
let a03 = "<textarea title=\"LayoutVideo3\" style=\"display:none;\">http://db51.ol/fo1/vL29wdC9kYm1ha2VyL2RhdGFiYXNlL3VjaXR5MS9mby9aWjAwMEJXSy5tcDQ=/IcelandWaterfall.mp4480270mp4u1601,J1599,G1599,g1670,G1625,G1613,G2013</textarea></body>"
let a04 = "<textarea title=\"LayoutVideo3\" style=\"display:none;\">http://db51.ol/fo1/vL29wdC9kYm1ha2VyL2RhdGFiYXNlL3VjaXR5MS9mby9aWjAwMEJYRS5tcDQ=/Epsilon1.mp4|http://db51.ol/fo1/vL29wdC9kYm1ha2VyL2RhdGFiYXNlL3VjaXR5MS9mby9aWjAwMEJXSy5tcDQ=/IcelandWaterfall.mp4480270mp4u1601,J1599,G1599,g1670,G1625,G1613,G2013</textarea></body>"
let a02 = "aaa"

//let strArr =
let fullName = "First Last"
let fullNameArr = a04.characters.split{$0 == " "}.map(String.init)
fullNameArr[0]
fullNameArr[1]
//try print(tryRegex(a01))
//try print(findNumber(a01, patte: "left"))
//try print(findNumber(a01, patte: "top"))
//try print(findNumber(a01, patte: "z-index"))
//try print(tryRegex(a02))


