//: [Previous](@previous)

import Foundation

func unescape(src:String)->String{
	let a = src.stringByReplacingOccurrencesOfString("%u", withString: "\\u")
	let transform:NSString = "Any-Hex/Java"
	
	let convertedString = a.mutableCopy() as! NSMutableString
	
	CFStringTransform(convertedString, nil, transform , true)
	
	var tmp = ""
	var indexS = 0
	let srcMain = convertedString as String

	
	while (indexS < srcMain.characters.count){
		let indexR = srcMain.startIndex.advancedBy(indexS)
		if (srcMain[indexR] == "%" ){
			let indR1 = indexR.advancedBy(1)
			if (srcMain[indR1]=="u"){
				let s1 = indR1.advancedBy(1)
				let e1 = indR1.advancedBy(5)
				let hex = srcMain[s1..<e1]
				let value = UInt32(strtoul(hex, nil, 16))
				let dao:String = String(UnicodeScalar(value))
				tmp += dao
				indexS += 6
			}else{
				let s1 = indR1.advancedBy(0)
				let e1 = indR1.advancedBy(2)
				let hex = srcMain[s1..<e1]
				let value = UInt32(strtoul(hex, nil, 16))
				let dao:String = String(UnicodeScalar(value))
				tmp += dao
				indexS += 3
			}
		}else{
			tmp += String(srcMain[indexR])
			indexS+=1
		}
	}
	return tmp
}
let a = "\u{01}480\u{01}270\u{01}mp4\u{01}u1601,J1599,G1599,g1670,G1625,G1613,G2013"
let b = "%E7%99%BD%E6%97%A5%E5%A4%A2%E5%86%92%E9%9A%AA%E7%8E%8B"
let c = "%u8C93%u8C93%28%u256F%B0%u25A1%B0%uFF09%u256F%uFE35%20%u253B%u2501%u253B%uD83D%uDC31%uD83D%uDC31"
let d = "%u6E2C%u8A66%u4E0A%u67B6"
let e = "🐱"
let a1 = "%u50b3%u9001%u5931%u6557%uff0c%u56e0%u70ba%u60a8%u5617%u8a66%u50b3%u9001%u7121%u6548%u7684%u6a94%u6848%u3002"
let a2 = "%u50b3%u9001%u5931%u6557%uff0c%u56e0%u70ba%u60a8%u5617%u8a66%u50b3%u9001%u7121%u6548%u7684%u6a94%u6848%u3002"
print(unescape(b))
print(unescape(d))
print(unescape(c))
print(unescape(d), d)
print("\u{2665}")
print("\u{1F496}")
//: [Next](@next)
print(unescape(a2))
print(a2.stringByRemovingPercentEncoding)